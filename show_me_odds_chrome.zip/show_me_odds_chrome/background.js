// Function to get the current active tab's URL
function getCurrentTabUrl(callback) {
  chrome.tabs.query({ active: true, currentWindow: true }, (tabs) => {
    let activeTab = tabs[0];
    let activeTabUrl = activeTab.url;
    callback(activeTabUrl, activeTab.id);
  });
}

// Listener for the extension icon click
chrome.action.onClicked.addListener(() => {
  getCurrentTabUrl((url, tabId) => {
    if (url.includes("dataservices.betgenius")) {
      console.log("URL is dataservices.betgenius");
      // Inject ds_script.js for dataservices.betgenius
      chrome.scripting.executeScript({
        target: { tabId: tabId },
        files: ["ds_script.js"]
      });
    } else if (url.includes("modelling-americanfootball")) {
      console.log("URL is modelling-americanfootball");
      // Inject ui_script.js for modelling-americanfootball
      chrome.scripting.executeScript({
        target: { tabId: tabId },
        files: ["ui_script.js"]
      });
    } else {
      console.log("URL is something else");
      // Inject bookies_script.js for other URLs
      chrome.scripting.executeScript({
        target: { tabId: tabId },
        files: ["bookies_script.js"]
      });
    }
  });
});