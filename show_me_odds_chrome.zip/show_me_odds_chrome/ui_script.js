//special model console


// Regular expression to match American odds (e.g., +150, -200)
const regex =  /\d+\.\d{2}/;


// Function to find all elements in the body that contain the pattern

function convertAmericanToDecimal(americanOdds) {
console.log("taken this oods ",americanOdds)
  odds = parseFloat(americanOdds);

  if (isNaN(odds)) {
    //throw new Error('Invalid American odds format');

   americanOdds = "-" + americanOdds.substring(1);

    odds = parseFloat(americanOdds);
	
  }

  let decimalOdds;
  if (odds >= 2) {
    decimalOdds = Math.round((odds*100)-100);
    decimalOdds = decimalOdds.toString()
    decimalOdds = "+" + decimalOdds
decimalOdds = odds.toString() + " ("+decimalOdds+")"
  } else {
    decimalOdds = -1*Math.round(100/(odds-1));
    decimalOdds = decimalOdds.toString()
decimalOdds = odds.toString() + " ("+decimalOdds+")"
  }

  //return decimalOdds.toFixed(2); // Optional: format to 2 decimal places
return decimalOdds
}





// Function to handle text content changes
function handleTextChange(mutationsList, observer) {
  const changedElements = [];
  
  for (const mutation of mutationsList) {
    
            if (mutation.type === 'characterData') {
              console.log('Elements with changed text content:', mutation.target.textContent);
	      console.log(`The old value was: ${mutation.oldValue}`);
              console.log('but this parentNode was passed', mutation.target.parentNode);
if (mutation.oldValue != mutation.target.textContent){
              changedElements.push(mutation.target.parentNode);}
            }
          
            else if (mutation.type === 'childList') {
                console.log('Child node added or removed:', mutation);
                // Observe new child nodes as well
                //let parentElement = mutation.target;

                if (mutation.addedNodes.length > 0){

                  

                  for (let element of mutation.addedNodes) {

                    changedElements.push(element);





                  } 
                //let matchingElement = findMatchingElement(parentElement, regex);
                //console.log(matchingElement.textContent, " was found");
            
            
            }

            }

  }
  

  
  if (changedElements.length > 0) {




      for (let element_ of changedElements) {
      // Check if the element's text content matches the pattern
	
          elementsWithOdds = extract_text_nodes_based_on_regex(element_, regex);



          elementsWithOdds.forEach(textNode => {
            console.log('Matching text node:', textNode.textContent);
          let decimalOdds = convertAmericanToDecimal(textNode.textContent);
            textNode.textContent = decimalOdds
          });




}

}

}


function extract_text_nodes_based_on_regex(node, regex) {
   matchingTextNodes = [];

  function getTextNodes(element) {
    element.childNodes.forEach(child => {
      if (child.nodeType === Node.TEXT_NODE && regex.test(child.textContent)) {
        matchingTextNodes.push(child);
      } else if (child.nodeType === Node.ELEMENT_NODE) {
        getTextNodes(child);
      }
    });
  }
  console.log("passing ",node)
  getTextNodes(node);
  return matchingTextNodes;
}



// Start the search from document.body
 textNodesInBody = extract_text_nodes_based_on_regex(document.body, regex);

// Log the text content of each matching text node
textNodesInBody.forEach(textNode => {
let trimmedStr = textNode.textContent.trim();

// Convert the trimmed string to a number
//let number = parseFloat(trimmedStr);
  console.log('Matching text node:', trimmedStr);
let decimalOdds = convertAmericanToDecimal(trimmedStr);
  textNode.textContent = decimalOdds
});




// Create an observer instance linked to the callback function
const observer = new MutationObserver(handleTextChange);

// Options for the observer (which mutations to observe)
const config = { characterData: true, characterDataOldValue: true, childList: true, subtree: true, attributes: false };

// Start observing the document body
observer.observe(document.body, config);




